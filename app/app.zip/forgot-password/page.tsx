"use client";

import { useState, useRef, useCallback } from "react";
import Link from "next/link";
import { LogoMark } from "../sign-in/page";

type Step = "email" | "otp" | "done";

export default function ForgotPasswordPage() {
  const [step, setStep]             = useState<Step>("email");
  const [email, setEmail]           = useState("");
  const [newPassword, setNewPass]   = useState("");
  const [challengeToken, setToken]  = useState("");
  const [otp, setOtp]               = useState(["", "", "", "", "", ""]);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState("");
  const [showPass, setShowPass]     = useState(false);

  async function handleSendOtp(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/email-otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to send OTP.");
      setToken(data.challengeToken);
      setStep("otp");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }

  async function handleVerify(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const code = otp.join("");
    if (code.length < 6) { setError("Enter all 6 digits."); return; }
    if (newPassword.length < 8) { setError("Password must be at least 8 characters."); return; }
    setLoading(true);
    try {
      const res = await fetch("/api/auth/forgot-password/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp: code, challengeToken, newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification failed.");
      // ── TODO: sign in with custom token ────────────────────────────
      await signInWithCustomToken(auth, data.customToken);
      router.push("/dashboard");
      setStep("done");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Verification failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main
      style={{
        minHeight: "100dvh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 16px",
        position: "relative",
        overflow: "hidden",
      }}
      className="grid-texture"
    >
      <div className="glow-blob" />

      <div className="animate-fade-up" style={{ width: "100%", maxWidth: 420 }}>
        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <LogoMark />
        </div>

        <div className="auth-card">

          {step === "email" && (
            <>
              <BackToSignIn />
              <h1 className="font-display" style={{ fontSize: "1.6rem", letterSpacing: "-0.02em", marginBottom: 4 }}>
                Reset password
              </h1>
              <p style={{ color: "var(--text-2)", fontSize: "0.875rem", marginBottom: 28 }}>
                Enter your email and we'll send a verification code.
              </p>
              <form onSubmit={handleSendOtp}>
                <div style={{ marginBottom: 20 }}>
                  <label className="label">Email address</label>
                  <input
                    className="input"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    required
                  />
                </div>
                {error && <ErrorBanner message={error} />}
                <button className="btn btn-primary" type="submit" disabled={loading}>
                  {loading ? <><span className="spinner" /> Sending code…</> : "Send reset code →"}
                </button>
              </form>
            </>
          )}

          {step === "otp" && (
            <>
              <BackToSignIn />
              <div style={{ marginBottom: 16 }}>
                <div style={{ height: 3, background: "var(--accent)", borderRadius: 99, width: "50%", marginBottom: 16 }} />
              </div>
              <h1 className="font-display" style={{ fontSize: "1.6rem", letterSpacing: "-0.02em", marginBottom: 4 }}>
                Verify & reset
              </h1>
              <p style={{ color: "var(--text-2)", fontSize: "0.875rem", marginBottom: 28 }}>
                Code sent to <strong style={{ color: "var(--text)" }}>{email}</strong>
              </p>
              <form onSubmit={handleVerify}>
                <div style={{ marginBottom: 20 }}>
                  <label className="label" style={{ marginBottom: 12 }}>Verification code</label>
                  <OtpInput value={otp} onChange={setOtp} />
                </div>
                <div style={{ marginBottom: 20 }}>
                  <label className="label">New password</label>
                  <div style={{ position: "relative" }}>
                    <input
                      className="input"
                      type={showPass ? "text" : "password"}
                      placeholder="Min. 8 characters"
                      value={newPassword}
                      onChange={e => setNewPass(e.target.value)}
                      required
                      style={{ paddingRight: 44 }}
                    />
                    <button type="button" onClick={() => setShowPass(v => !v)}
                      style={{ position:"absolute", right:12, top:"50%", transform:"translateY(-50%)",
                        background:"none", border:"none", cursor:"pointer",
                        color:"var(--text-3)", fontSize:"0.75rem", padding:"2px 4px" }}>
                      {showPass ? "hide" : "show"}
                    </button>
                  </div>
                </div>
                {error && <ErrorBanner message={error} />}
                <button className="btn btn-primary" type="submit" disabled={loading}>
                  {loading ? <><span className="spinner" /> Updating password…</> : "Reset password →"}
                </button>
                <button type="button"
                  onClick={() => { setStep("email"); setOtp(["","","","","",""]); setError(""); }}
                  style={{ width:"100%", marginTop:10, background:"none", border:"none",
                    color:"var(--text-3)", fontSize:"0.8rem", cursor:"pointer", padding:"6px" }}>
                  ← Back
                </button>
              </form>
            </>
          )}

          {step === "done" && (
            <div style={{ textAlign: "center", padding: "16px 0" }}>
              <div style={{
                width: 56, height: 56,
                background: "rgba(79,255,176,0.1)",
                border: "1px solid rgba(79,255,176,0.2)",
                borderRadius: "50%",
                display: "flex", alignItems: "center", justifyContent: "center",
                margin: "0 auto 20px",
                fontSize: "1.5rem",
              }}>✓</div>
              <h1 className="font-display" style={{ fontSize: "1.5rem", letterSpacing: "-0.02em", marginBottom: 8 }}>
                Password reset
              </h1>
              <p style={{ color: "var(--text-2)", fontSize: "0.875rem", marginBottom: 28, lineHeight: 1.6 }}>
                Your password has been updated. You're now signed in.
              </p>
              <Link href="/dashboard">
                <button className="btn btn-primary" type="button">
                  Go to dashboard →
                </button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}

function BackToSignIn() {
  return (
    <Link href="/sign-in" style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      fontSize: "0.78rem", color: "var(--text-3)",
      textDecoration: "none", marginBottom: 20,
    }}>
      ← Back to sign in
    </Link>
  );
}

function OtpInput({ value, onChange }: { value: string[]; onChange: (v: string[]) => void }) {
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const handleKey = useCallback((i: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !value[i] && i > 0) refs.current[i - 1]?.focus();
  }, [value]);
  const handleChange = useCallback((i: number, v: string) => {
    const digit = v.replace(/\D/g, "").slice(-1);
    const next = [...value]; next[i] = digit; onChange(next);
    if (digit && i < 5) refs.current[i + 1]?.focus();
  }, [value, onChange]);
  const handlePaste = useCallback((e: React.ClipboardEvent) => {
    const text = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 6);
    const next = [...value]; text.split("").forEach((d, i) => { next[i] = d; }); onChange(next);
    refs.current[Math.min(text.length, 5)]?.focus(); e.preventDefault();
  }, [value, onChange]);
  return (
    <div style={{ display: "flex", gap: 8, justifyContent: "space-between" }}>
      {value.map((digit, i) => (
        <input key={i} ref={el => { refs.current[i] = el; }}
          className={`otp-input${digit ? " filled" : ""}`}
          type="text" inputMode="numeric" maxLength={1}
          value={digit} onChange={e => handleChange(i, e.target.value)}
          onKeyDown={e => handleKey(i, e)} onPaste={handlePaste} />
      ))}
    </div>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div style={{
      background: "rgba(255,94,94,0.08)", border: "1px solid rgba(255,94,94,0.2)",
      borderRadius: "var(--radius)", padding: "10px 14px", marginBottom: 16,
      fontSize: "0.8rem", color: "var(--danger)", display: "flex", gap: 8,
    }}>
      <span>⚠</span><span>{message}</span>
    </div>
  );
}

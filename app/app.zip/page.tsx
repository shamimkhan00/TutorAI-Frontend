"use client";
/**
 * DROP-IN REPLACEMENT for app/page.tsx
 * ─────────────────────────────────────
 * Keeps your existing signed-in/signed-out component structure.
 * Replaces the default Next.js page with branded TutorAI landing.
 * Your existing AuthStatus, SignedIn, SignedOut components plug in here unchanged.
 */

import { LogoMark } from "./sign-in/page";

// ── Import your existing auth components unchanged ─────────────────────
// import AuthStatus from "./components/auth-status";

export default function HomePage() {
  return (
    <main
      style={{
        minHeight: "100dvh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px",
        position: "relative",
        overflow: "hidden",
        flexDirection: "column",
        gap: 40,
      }}
      className="grid-texture"
    >
      <div className="glow-blob" />

      {/* Hero */}
      <div className="animate-fade-up" style={{ textAlign: "center", maxWidth: 560 }}>
        <div style={{ marginBottom: 24 }}>
          <LogoMark size={44} />
        </div>
        <h1
          className="font-display"
          style={{
            fontSize: "clamp(2.2rem, 5vw, 3.2rem)",
            lineHeight: 1.1,
            letterSpacing: "-0.03em",
            marginBottom: 16,
            color: "var(--text)",
          }}
        >
          Learn anything,<br />
          <span style={{ color: "var(--accent)" }}>faster.</span>
        </h1>
        <p style={{ fontSize: "1rem", color: "var(--text-2)", lineHeight: 1.7, maxWidth: 420, margin: "0 auto 32px" }}>
          Upload your notes, textbooks, or slides. Ask questions, get summaries, understand deeply.
        </p>

        {/* ── AuthStatus replaces this block ────────────────────────── */}
        {/* <AuthStatus /> */}
        {/* 
            Your existing auth-status.tsx renders SignedIn or SignedOut.
            Replace the buttons below with <AuthStatus /> once wired.
        */}
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <a href="/sign-in">
            <button className="btn btn-primary" style={{ width: "auto", padding: "11px 28px", fontSize: "0.9rem" }}>
              Sign in →
            </button>
          </a>
          <a href="/sign-up">
            <button className="btn btn-outline" style={{ padding: "11px 28px", fontSize: "0.9rem" }}>
              Create account
            </button>
          </a>
        </div>
      </div>

      {/* Feature cards */}
      <div
        className="animate-fade-up"
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
          gap: 12,
          maxWidth: 560,
          width: "100%",
          animationDelay: "0.1s",
        }}
      >
        {[
          { icon: "📄", title: "Upload documents", desc: "PDF, images, text" },
          { icon: "💬", title: "Chat with AI", desc: "Ask anything about your docs" },
          { icon: "✦",  title: "Auto summaries", desc: "Key points extracted instantly" },
          { icon: "🔍", title: "Source citations", desc: "Every answer traced to source" },
        ].map(f => (
          <div key={f.title} className="card"
            style={{ padding: "16px", textAlign: "center" }}>
            <div style={{ fontSize: "1.4rem", marginBottom: 8 }}>{f.icon}</div>
            <p style={{ fontSize: "0.8rem", fontWeight: 600, color: "var(--text)", marginBottom: 4 }}>{f.title}</p>
            <p style={{ fontSize: "0.72rem", color: "var(--text-3)", lineHeight: 1.5 }}>{f.desc}</p>
          </div>
        ))}
      </div>
    </main>
  );
}

import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TutorAI — Learn anything, faster",
  description: "Upload documents and chat with AI to understand them deeply.",
  icons: { icon: "/favicon.webp" },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <head>
        {/* Fonts are loaded in globals.css via @import */}
      </head>
      <body>{children}</body>
    </html>
  );
}

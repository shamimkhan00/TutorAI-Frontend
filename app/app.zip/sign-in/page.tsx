"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { signInWithEmailAndPassword, type AuthError } from "firebase/auth";

import { useAuthUser } from "@/app/hooks/use-auth-user";
import { auth } from "@/lib/firebase";

export default function SignInPage() {
  const router = useRouter();
  const { loading: authLoading, user } = useAuthUser();

  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");
  const [showPass, setShowPass] = useState(false);

  // Redirect if already logged in
  useEffect(() => {
    if (!authLoading && user) {
      router.replace("/");
    }
  }, [authLoading, user, router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      router.replace("/dashboard");
    } catch (err: unknown) {
      const authError = err as AuthError;
      setError(authError.message || "Sign-in failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main
      style={{
        minHeight: "100dvh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "24px 16px",
        position: "relative",
        overflow: "hidden",
      }}
      className="grid-texture"
    >
      <div className="glow-blob" />

      <div className="animate-fade-up" style={{ width: "100%", maxWidth: 420 }}>

        <div style={{ textAlign: "center", marginBottom: 32 }}>
          <LogoMark />
          <p style={{ color: "var(--text-3)", fontSize: "0.8rem", marginTop: 8 }}>
            Your AI-powered learning assistant
          </p>
        </div>

        <div className="auth-card">
          <h1
            className="font-display"
            style={{ fontSize: "1.6rem", marginBottom: 4, letterSpacing: "-0.02em" }}
          >
            Welcome back
          </h1>
          <p style={{ color: "var(--text-2)", fontSize: "0.875rem", marginBottom: 28 }}>
            Sign in to continue learning
          </p>

          <form onSubmit={handleSubmit}>
            <FieldGroup label="Email address">
              <input
                className={`input${error ? " error" : ""}`}
                type="email"
                autoComplete="email"
                placeholder="you@example.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                required
              />
            </FieldGroup>

            <FieldGroup label="Password" style={{ marginBottom: 6 }}>
              <div style={{ position: "relative" }}>
                <input
                  className={`input${error ? " error" : ""}`}
                  type={showPass ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  required
                  style={{ paddingRight: 44 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  style={{
                    position: "absolute", right: 12, top: "50%",
                    transform: "translateY(-50%)",
                    background: "none", border: "none", cursor: "pointer",
                    color: "var(--text-3)", fontSize: "0.75rem", padding: "2px 4px",
                  }}
                >
                  {showPass ? "hide" : "show"}
                </button>
              </div>
            </FieldGroup>

            <div style={{ textAlign: "right", marginBottom: 20 }}>
              <Link
                href="/forgot-password"
                style={{ fontSize: "0.75rem", color: "var(--text-3)" }}
                className="hover-accent"
              >
                Forgot password?
              </Link>
            </div>

            {error && <ErrorBanner message={error} />}

            <button className="btn btn-primary" type="submit" disabled={loading || authLoading}>
              {loading ? <><span className="spinner" /> Signing in…</> : "Sign in →"}
            </button>
          </form>

          <div className="divider" style={{ margin: "24px 0" }}>or</div>

          <p style={{ textAlign: "center", fontSize: "0.875rem", color: "var(--text-2)" }}>
            New here?{" "}
            <Link href="/sign-up" style={{ color: "var(--accent)", fontWeight: 500 }}>
              Create account
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}

/* ─── Sub-components ──────────────────────────────────────────────────── */
function FieldGroup({
  label, children, style,
}: { label: string; children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{ marginBottom: 16, ...style }}>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div style={{
      background: "rgba(255,94,94,0.08)",
      border: "1px solid rgba(255,94,94,0.2)",
      borderRadius: "var(--radius)",
      padding: "10px 14px",
      marginBottom: 16,
      fontSize: "0.8rem",
      color: "var(--danger)",
      display: "flex",
      gap: 8,
      alignItems: "flex-start",
    }}>
      <span style={{ fontSize: "0.9rem" }}>⚠</span>
      <span>{message}</span>
    </div>
  );
}

export function LogoMark({ size = 36 }: { size?: number }) {
  return (
    <div style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
    }}>
      <div style={{
        width: size, height: size,
        background: "var(--accent)",
        borderRadius: "10px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: size * 0.45 + "px",
        fontFamily: "var(--font-display)",
        color: "#0d0e14",
        fontWeight: 700,
        flexShrink: 0,
      }}>T</div>
      <span style={{
        fontFamily: "var(--font-display)",
        fontSize: size * 0.65 + "px",
        letterSpacing: "-0.02em",
        color: "var(--text)",
      }}>TutorAI</span>
    </div>
  );
}
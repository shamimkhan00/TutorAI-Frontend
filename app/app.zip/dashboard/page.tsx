"use client";
/**
 * app/dashboard/page.tsx  (NEW FILE — doesn't touch existing app/page.tsx)
 * ─────────────────────────────────────────────────────────────────────────
 * Full 3-panel TutorAI dashboard UI.
 * Redirect here after sign-in/sign-up in your auth flows.
 * All data is mock — wire API calls where marked with ── TODO ──
 */

import { useState, useRef, useEffect, useCallback } from "react";
import { LogoMark } from "../sign-in/page";

/* ─── Types ──────────────────────────────────────────────────────────── */
type DocStatus = "uploading" | "processing" | "ready" | "error";
type DocType   = "pdf" | "image" | "text";
type PanelTab  = "summary" | "keypoints" | "sources";
type MsgRole   = "user" | "assistant";

interface Doc {
  id: string; name: string; type: DocType;
  size: number; status: DocStatus; progress: number;
  summary?: string; keyPoints?: string[];
}
interface Msg {
  id: string; role: MsgRole; content: string;
  streaming?: boolean; citations?: { doc: string; page: number; excerpt: string }[];
}

/* ─── Mock data ──────────────────────────────────────────────────────── */
const MOCK_DOCS: Doc[] = [
  { id: "d1", name: "Neural Networks 101.pdf", type: "pdf", size: 2_450_000, status: "ready", progress: 100,
    summary: "A comprehensive introduction to neural networks covering biological inspiration, mathematical foundations, backpropagation, CNNs, and RNNs.",
    keyPoints: ["Inspired by biological neurons", "Backpropagation trains networks via chain rule", "CNNs excel at image tasks", "RNNs handle sequential data", "Dropout prevents overfitting"] },
  { id: "d2", name: "transformer_paper.pdf", type: "pdf", size: 1_230_000, status: "ready", progress: 100,
    summary: "Covers the Transformer architecture from 'Attention Is All You Need' — self-attention, multi-head attention, positional encoding, and the encoder-decoder structure.",
    keyPoints: ["Self-attention replaces recurrence", "Multi-head attention attends to multiple subspaces", "Positional encoding injects order", "Highly parallelizable"] },
];
const MOCK_INIT_MSGS: Msg[] = [
  { id: "m0", role: "assistant",
    content: "Hello! I'm TutorAI. Upload your notes, textbooks, or slides and I'll help you understand them, answer questions, and generate summaries.\n\nWhat would you like to learn?" },
];
const MOCK_RESPONSE = `The Transformer architecture replaced recurrence with **self-attention**, letting every token attend to every other token directly.

**Key components:**
- **Multi-head attention** — multiple attention heads learn different relationship types simultaneously
- **Positional encoding** — sinusoidal embeddings inject position information since there's no sequential processing
- **Feed-forward layers** — applied position-wise after attention
- **Layer normalization** — stabilizes training throughout

This design enabled far larger datasets and became the foundation for GPT, BERT, and all modern LLMs.`;

/* ─── Utils ──────────────────────────────────────────────────────────── */
function uid() { return Math.random().toString(36).slice(2); }
function fmtSize(b: number) {
  if (b < 1024) return b + " B";
  if (b < 1_048_576) return (b / 1024).toFixed(1) + " KB";
  return (b / 1_048_576).toFixed(1) + " MB";
}
function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

/* ─── Simple markdown renderer ───────────────────────────────────────── */
function renderMarkdown(text: string): string {
  return text
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, '<code>$1</code>')
    .replace(/^### (.+)$/gm, "<h3>$1</h3>")
    .replace(/^## (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")
    .replace(/^- (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>[\s\S]*?<\/li>)/g, "<ul>$1</ul>")
    .replace(/\n\n/g, "</p><p>")
    .replace(/^(?!<[h|u|l])(.+)$/gm, (m) => m.startsWith("<") ? m : `<p>${m}</p>`);
}

/* ═══════════════════════════════════════════════════════════════════════
   MAIN DASHBOARD
═══════════════════════════════════════════════════════════════════════ */
export default function DashboardPage() {
  const [docs, setDocs]           = useState<Doc[]>(MOCK_DOCS);
  const [activeDocId, setActiveDoc] = useState<string>("d1");
  const [msgs, setMsgs]           = useState<Msg[]>(MOCK_INIT_MSGS);
  const [input, setInput]         = useState("");
  const [loading, setLoading]     = useState(false);
  const [panelTab, setPanelTab]   = useState<PanelTab>("summary");
  const [strictMode, setStrict]   = useState(true);
  const [webSearch, setWebSearch] = useState(false);
  const [sidebarOpen, setSidebar] = useState(true);
  const [rightOpen, setRight]     = useState(true);
  const [dragging, setDragging]   = useState(false);

  const chatEndRef  = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const textareaRef  = useRef<HTMLTextAreaElement>(null);

  const activeDoc = docs.find(d => d.id === activeDocId) ?? null;

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs]);

  /* ── File upload ──────────────────────────────────────────────────── */
  const handleFiles = useCallback(async (files: FileList | File[]) => {
    const arr = Array.from(files);
    for (const file of arr) {
      const id = uid();
      const type: DocType = file.type === "application/pdf" ? "pdf"
        : file.type.startsWith("image/") ? "image" : "text";
      const doc: Doc = { id, name: file.name, type, size: file.size, status: "uploading", progress: 0 };
      setDocs(d => [...d, doc]);
      setActiveDoc(id);

      // ── TODO: replace this mock with your real API call ──────────────
      // const fd = new FormData(); fd.append("file", file);
      // const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/upload`, { method:"POST", body: fd });
      // const data = await res.json();
      // setDocs(d => d.map(x => x.id === id ? { ...x, status:"ready", progress:100, summary: data.summary, keyPoints: data.key_points } : x));

      for (let p = 10; p <= 90; p += 15) { await sleep(120); setDocs(d => d.map(x => x.id === id ? { ...x, progress: p } : x)); }
      setDocs(d => d.map(x => x.id === id ? { ...x, status: "processing", progress: 90 } : x));
      await sleep(600);
      setDocs(d => d.map(x => x.id === id ? {
        ...x, status: "ready", progress: 100,
        summary: "AI-extracted summary will appear here once wired to your backend.",
        keyPoints: ["Key insight 1 from the document", "Key insight 2", "Key insight 3"],
      } : x));
    }
  }, []);

  /* ── Drag & drop ──────────────────────────────────────────────────── */
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDragging(false);
    if (e.dataTransfer.files.length) handleFiles(e.dataTransfer.files);
  }, [handleFiles]);

  /* ── Chat send ────────────────────────────────────────────────────── */
  const handleSend = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");

    const userMsg: Msg = { id: uid(), role: "user", content: text };
    setMsgs(m => [...m, userMsg]);
    setLoading(true);

    const aiId = uid();
    const aiMsg: Msg = { id: aiId, role: "assistant", content: "", streaming: true };
    setMsgs(m => [...m, aiMsg]);

    // ── TODO: replace mock stream with real API ─────────────────────
    // const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/query`, {
    //   method: "POST", headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ question: text, document_ids: [activeDocId], strict_mode: strictMode, web_search: webSearch })
    // });
    // const data = await res.json();
    // setMsgs(m => m.map(x => x.id === aiId ? { ...x, content: data.answer, streaming: false, citations: data.citations } : x));

    const words = MOCK_RESPONSE.split(" ");
    let acc = "";
    for (const w of words) {
      await sleep(25 + Math.random() * 35);
      acc += w + " ";
      setMsgs(m => m.map(x => x.id === aiId ? { ...x, content: acc } : x));
    }
    setMsgs(m => m.map(x => x.id === aiId ? {
      ...x, streaming: false,
      citations: [{ doc: "Neural Networks 101.pdf", page: 7, excerpt: "Backpropagation computes gradients via the chain rule." }],
    } : x));
    setLoading(false);
  }, [input, loading, activeDocId, strictMode, webSearch]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  /* ── Auto-resize textarea ─────────────────────────────────────────── */
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 140) + "px";
    }
  }, [input]);

  /* ─────────────────────────────────────────────────────────────────── */
  return (
    <div
      style={{ display: "flex", height: "100dvh", overflow: "hidden", background: "var(--bg)" }}
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={handleDrop}
    >
      {/* Global drop overlay */}
      {dragging && (
        <div style={{
          position: "fixed", inset: 0, zIndex: 50,
          background: "rgba(13,14,20,0.85)",
          display: "flex", alignItems: "center", justifyContent: "center",
          backdropFilter: "blur(4px)",
        }}>
          <div style={{
            border: "2px dashed var(--accent)", borderRadius: "var(--radius-xl)",
            padding: "60px 80px", textAlign: "center",
          }}>
            <div style={{ fontSize: "2.5rem", marginBottom: 12 }}>⬆</div>
            <p style={{ fontFamily: "var(--font-display)", fontSize: "1.4rem", color: "var(--accent)" }}>
              Drop files to upload
            </p>
            <p style={{ color: "var(--text-2)", fontSize: "0.875rem", marginTop: 6 }}>PDF, images, text files</p>
          </div>
        </div>
      )}

      {/* ── LEFT SIDEBAR ─────────────────────────────────────────────── */}
      {sidebarOpen && (
        <aside style={{
          width: 240, flexShrink: 0,
          borderRight: "1px solid var(--border)",
          background: "var(--bg-2)",
          display: "flex", flexDirection: "column",
          overflow: "hidden",
        }}>
          {/* Logo row */}
          <div style={{
            padding: "16px 16px 12px",
            borderBottom: "1px solid var(--border)",
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <LogoMark size={28} />
            <button className="btn btn-icon" onClick={() => setSidebar(false)} title="Collapse sidebar"
              style={{ width: 28, height: 28, fontSize: "0.75rem" }}>✕</button>
          </div>

          {/* Upload button */}
          <div style={{ padding: "12px 12px 8px" }}>
            <input ref={fileInputRef} type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.txt,.md"
              style={{ display: "none" }} onChange={e => e.target.files && handleFiles(e.target.files)} />
            <button className="btn btn-outline" style={{ width: "100%", gap: 8, fontSize: "0.8rem" }}
              onClick={() => fileInputRef.current?.click()}>
              <span>+</span> Upload document
            </button>
          </div>

          {/* Docs list */}
          <div style={{ flex: 1, overflowY: "auto", padding: "4px 8px" }}>
            {docs.length === 0 ? (
              <div style={{ padding: "24px 12px", textAlign: "center", color: "var(--text-3)", fontSize: "0.78rem", lineHeight: 1.6 }}>
                No documents yet.<br />Upload a PDF or image to start.
              </div>
            ) : (
              <>
                <p style={{ fontSize: "0.65rem", fontWeight: 600, letterSpacing: "0.08em",
                  textTransform: "uppercase", color: "var(--text-3)", padding: "8px 4px 4px" }}>
                  Documents
                </p>
                {docs.map(doc => (
                  <DocItem key={doc.id} doc={doc} active={doc.id === activeDocId}
                    onClick={() => setActiveDoc(doc.id)}
                    onDelete={() => setDocs(d => d.filter(x => x.id !== doc.id))} />
                ))}
              </>
            )}
          </div>

          {/* Settings toggles */}
          <div style={{
            borderTop: "1px solid var(--border)",
            padding: "12px 14px",
            display: "flex", flexDirection: "column", gap: 10,
          }}>
            <ToggleRow label="Strict mode" on={strictMode} onChange={() => setStrict(v => !v)} />
            <ToggleRow label="Web search" on={webSearch} onChange={() => setWebSearch(v => !v)} />
          </div>

          {/* User footer */}
          <div style={{
            borderTop: "1px solid var(--border)",
            padding: "10px 14px",
            display: "flex", alignItems: "center", gap: 8,
          }}>
            <div style={{
              width: 28, height: 28, borderRadius: "50%",
              background: "var(--accent)", color: "#0d0e14",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: "0.75rem", fontWeight: 600, flexShrink: 0,
            }}>U</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ fontSize: "0.78rem", color: "var(--text)", fontWeight: 500,
                overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                user@example.com
              </p>
              <p style={{ fontSize: "0.68rem", color: "var(--text-3)" }}>Student</p>
            </div>
            {/* TODO: onClick → auth.signOut() */}
            <button className="btn btn-ghost" style={{ padding: "4px 6px", fontSize: "0.7rem" }}>
              Sign out
            </button>
          </div>
        </aside>
      )}

      {/* ── CENTER: CHAT ─────────────────────────────────────────────── */}
      <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

        {/* Top bar */}
        <header style={{
          height: 52, flexShrink: 0,
          borderBottom: "1px solid var(--border)",
          display: "flex", alignItems: "center",
          padding: "0 16px", gap: 8,
          background: "var(--bg-2)",
        }}>
          {!sidebarOpen && (
            <button className="btn btn-icon" onClick={() => setSidebar(true)} title="Open sidebar">☰</button>
          )}
          <div style={{ flex: 1, minWidth: 0 }}>
            {activeDoc ? (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <DocIcon type={activeDoc.type} size={16} />
                <span style={{ fontSize: "0.8rem", color: "var(--text-2)",
                  overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {activeDoc.name}
                </span>
                <StatusBadge status={activeDoc.status} />
              </div>
            ) : (
              <span style={{ fontSize: "0.8rem", color: "var(--text-3)" }}>No document selected</span>
            )}
          </div>
          <button className="btn btn-ghost" style={{ fontSize: "0.75rem", padding: "5px 10px" }}
            onClick={() => setMsgs(MOCK_INIT_MSGS)}>
            Clear chat
          </button>
          {!rightOpen && (
            <button className="btn btn-icon" onClick={() => setRight(true)} title="Open panel">⟩</button>
          )}
        </header>

        {/* Messages */}
        <div style={{ flex: 1, overflowY: "auto", padding: "24px 16px", display: "flex", flexDirection: "column", gap: 16 }}>
          {msgs.map(msg => (
            <ChatBubble key={msg.id} msg={msg} />
          ))}
          {loading && msgs[msgs.length - 1]?.role === "user" && (
            <div style={{ display: "flex", gap: 10, alignItems: "flex-end" }}>
              <AiAvatar />
              <div className="bubble-ai" style={{ padding: "14px 18px" }}>
                <div className="typing-dots" style={{ display: "flex", gap: 5 }}>
                  <span /><span /><span />
                </div>
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input area */}
        <div style={{
          borderTop: "1px solid var(--border)",
          padding: "12px 16px",
          background: "var(--bg-2)",
        }}>
          {docs.length === 0 && (
            <UploadPrompt onUpload={() => fileInputRef.current?.click()} />
          )}
          <div style={{
            display: "flex", gap: 8, alignItems: "flex-end",
            background: "var(--bg-3)",
            border: "1px solid var(--border-2)",
            borderRadius: "var(--radius-lg)",
            padding: "8px 8px 8px 14px",
          }}>
            <input type="file" multiple accept=".pdf,.png,.jpg,.jpeg,.txt"
              style={{ display: "none" }} id="chat-file-input"
              onChange={e => e.target.files && handleFiles(e.target.files)} />
            <label htmlFor="chat-file-input" title="Attach file"
              style={{ color: "var(--text-3)", cursor: "pointer", fontSize: "1.1rem",
                lineHeight: 1, paddingBottom: 6, transition: "color 0.15s" }}
              className="hover-accent">
              ⊕
            </label>
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={activeDoc ? `Ask about "${activeDoc.name}"…` : "Upload a document to start…"}
              disabled={loading}
              style={{
                flex: 1, background: "none", border: "none", outline: "none",
                fontFamily: "var(--font-body)", fontSize: "0.875rem", color: "var(--text)",
                resize: "none", lineHeight: 1.55, minHeight: 22, maxHeight: 140,
                paddingTop: 4,
              }}
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || loading}
              style={{
                width: 36, height: 36, flexShrink: 0,
                background: input.trim() && !loading ? "var(--accent)" : "var(--bg-4)",
                border: "none", borderRadius: "var(--radius)",
                cursor: input.trim() && !loading ? "pointer" : "default",
                color: input.trim() && !loading ? "#0d0e14" : "var(--text-3)",
                fontSize: "1rem", display: "flex", alignItems: "center", justifyContent: "center",
                transition: "all 0.15s", flexShrink: 0,
              }}
            >
              {loading ? <span className="spinner" style={{ width: 14, height: 14 }} /> : "↑"}
            </button>
          </div>
          <p style={{ textAlign: "center", fontSize: "0.68rem", color: "var(--text-3)", marginTop: 8 }}>
            TutorAI can make mistakes. Verify important information.
          </p>
        </div>
      </main>

      {/* ── RIGHT PANEL ──────────────────────────────────────────────── */}
      {rightOpen && (
        <aside style={{
          width: 320, flexShrink: 0,
          borderLeft: "1px solid var(--border)",
          background: "var(--bg-2)",
          display: "flex", flexDirection: "column",
          overflow: "hidden",
        }}>
          {/* Header */}
          <div style={{
            height: 52, flexShrink: 0,
            borderBottom: "1px solid var(--border)",
            display: "flex", alignItems: "center",
            padding: "0 12px", gap: 8,
          }}>
            <div className="tab-bar" style={{ flex: 1 }}>
              {(["summary","keypoints","sources"] as PanelTab[]).map(t => (
                <div key={t} className={`tab-item${panelTab === t ? " active" : ""}`}
                  onClick={() => setPanelTab(t)}>
                  {{ summary: "Summary", keypoints: "Key Points", sources: "Sources" }[t]}
                </div>
              ))}
            </div>
            <button className="btn btn-icon" onClick={() => setRight(false)}
              style={{ width: 28, height: 28, flexShrink: 0 }}>✕</button>
          </div>

          {/* Content */}
          <div style={{ flex: 1, overflowY: "auto", padding: "16px" }}>
            {!activeDoc ? (
              <EmptyPanel message="Select a document to see its summary and key points." />
            ) : activeDoc.status !== "ready" ? (
              <ProcessingPanel status={activeDoc.status} progress={activeDoc.progress} />
            ) : (
              <>
                {panelTab === "summary" && (
                  <SummaryPanel doc={activeDoc} />
                )}
                {panelTab === "keypoints" && (
                  <KeyPointsPanel doc={activeDoc} />
                )}
                {panelTab === "sources" && (
                  <SourcesPanel msgs={msgs} />
                )}
              </>
            )}
          </div>

          {/* Upload zone */}
          <div style={{ padding: "12px", borderTop: "1px solid var(--border)" }}>
            <div
              className="dropzone"
              style={{ padding: "20px 16px" }}
              onClick={() => fileInputRef.current?.click()}
              onDragOver={e => e.preventDefault()}
            >
              <p style={{ fontSize: "0.8rem", color: "var(--text-3)", lineHeight: 1.5 }}>
                <span style={{ color: "var(--accent)", fontWeight: 500 }}>Click</span> or drag & drop<br />
                PDF, images, text files
              </p>
            </div>
          </div>
        </aside>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════
   SUB-COMPONENTS
═══════════════════════════════════════════════════════════════════════ */

function DocItem({ doc, active, onClick, onDelete }: { doc: Doc; active: boolean; onClick: () => void; onDelete: () => void }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div className={`doc-item${active ? " active" : ""}`}
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{ position: "relative" }}>
      <DocIcon type={doc.type} size={18} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <p style={{ fontSize: "0.78rem", color: "var(--text)", fontWeight: 500,
          overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{doc.name}</p>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <StatusBadge status={doc.status} />
          <span style={{ fontSize: "0.65rem", color: "var(--text-3)" }}>{fmtSize(doc.size)}</span>
        </div>
        {doc.status === "uploading" && (
          <div className="progress-track" style={{ marginTop: 4 }}>
            <div className="progress-fill" style={{ width: doc.progress + "%" }} />
          </div>
        )}
      </div>
      {hovered && (
        <button onClick={e => { e.stopPropagation(); onDelete(); }}
          style={{ background: "none", border: "none", cursor: "pointer",
            color: "var(--text-3)", fontSize: "0.75rem", padding: "2px 4px",
            position: "absolute", right: 6 }}>
          ✕
        </button>
      )}
    </div>
  );
}

function ChatBubble({ msg }: { msg: Msg }) {
  const isUser = msg.role === "user";
  return (
    <div className="animate-fade-in"
      style={{ display: "flex", gap: 10, flexDirection: isUser ? "row-reverse" : "row", alignItems: "flex-end" }}>
      {!isUser && <AiAvatar />}
      <div>
        <div className={isUser ? "bubble-user" : "bubble-ai"}>
          {isUser ? (
            <span style={{ whiteSpace: "pre-wrap" }}>{msg.content}</span>
          ) : (
            <div className="ai-prose"
              dangerouslySetInnerHTML={{ __html: renderMarkdown(msg.content) }} />
          )}
          {msg.streaming && (
            <span style={{
              display: "inline-block", width: 2, height: "1em",
              background: "var(--accent)", marginLeft: 2,
              animation: "typingBounce 0.8s infinite",
              verticalAlign: "text-bottom",
            }} />
          )}
        </div>
        {msg.citations && msg.citations.length > 0 && (
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
            {msg.citations.map((c, i) => (
              <div key={i} className="citation-chip" title={c.excerpt}>
                📄 {c.doc} · p.{c.page}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AiAvatar() {
  return (
    <div style={{
      width: 28, height: 28, flexShrink: 0,
      background: "var(--accent)", borderRadius: 8,
      display: "flex", alignItems: "center", justifyContent: "center",
      fontSize: "0.7rem", fontFamily: "var(--font-display)",
      color: "#0d0e14", fontWeight: 700,
    }}>T</div>
  );
}

function ToggleRow({ label, on, onChange }: { label: string; on: boolean; onChange: () => void }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}
      onClick={onChange} role="button" style={{ cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <span style={{ fontSize: "0.78rem", color: "var(--text-2)" }}>{label}</span>
      <div className={`toggle-track${on ? " on" : ""}`}>
        <div className="toggle-thumb" />
      </div>
    </div>
  );
}

function DocIcon({ type, size = 20 }: { type: DocType; size?: number }) {
  const icons = { pdf: "📄", image: "🖼", text: "📝" };
  return <span style={{ fontSize: size * 0.8 + "px", lineHeight: 1 }}>{icons[type]}</span>;
}

function StatusBadge({ status }: { status: DocStatus }) {
  const map = {
    ready:      { cls: "badge-ready",   label: "Ready" },
    processing: { cls: "badge-process", label: "Processing" },
    uploading:  { cls: "badge-upload",  label: "Uploading" },
    error:      { cls: "badge-error",   label: "Error" },
  };
  const { cls, label } = map[status];
  return <span className={`badge ${cls}`}>{label}</span>;
}

function SummaryPanel({ doc }: { doc: Doc }) {
  const [copied, setCopied] = useState(false);
  function copy() {
    navigator.clipboard.writeText(doc.summary ?? "");
    setCopied(true); setTimeout(() => setCopied(false), 1500);
  }
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <p style={{ fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.06em",
          textTransform: "uppercase", color: "var(--text-3)" }}>AI Summary</p>
        <button className="btn btn-ghost" style={{ padding: "3px 8px", fontSize: "0.7rem" }} onClick={copy}>
          {copied ? "✓ Copied" : "Copy"}
        </button>
      </div>
      <p style={{ fontSize: "0.85rem", color: "var(--text-2)", lineHeight: 1.7 }}>{doc.summary}</p>
    </div>
  );
}

function KeyPointsPanel({ doc }: { doc: Doc }) {
  return (
    <div>
      <p style={{ fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.06em",
        textTransform: "uppercase", color: "var(--text-3)", marginBottom: 12 }}>Key Points</p>
      {(doc.keyPoints ?? []).map((kp, i) => (
        <div key={i} style={{
          display: "flex", gap: 10, marginBottom: 10,
          padding: "10px 12px", background: "var(--bg-3)",
          borderRadius: "var(--radius)", border: "1px solid var(--border)",
        }}>
          <span style={{
            width: 20, height: 20, flexShrink: 0,
            background: "var(--accent-dim)", color: "var(--accent)",
            borderRadius: 5, display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: "0.65rem", fontFamily: "var(--font-mono)", fontWeight: 600,
          }}>{i + 1}</span>
          <p style={{ fontSize: "0.82rem", color: "var(--text-2)", lineHeight: 1.55 }}>{kp}</p>
        </div>
      ))}
    </div>
  );
}

function SourcesPanel({ msgs }: { msgs: Msg[] }) {
  const citations = msgs.flatMap(m => m.citations ?? []);
  if (citations.length === 0) {
    return <EmptyPanel message="Citations will appear here as you ask questions." />;
  }
  return (
    <div>
      <p style={{ fontSize: "0.7rem", fontWeight: 600, letterSpacing: "0.06em",
        textTransform: "uppercase", color: "var(--text-3)", marginBottom: 12 }}>
        Referenced Sources ({citations.length})
      </p>
      {citations.map((c, i) => (
        <div key={i} style={{
          marginBottom: 10, padding: "12px", background: "var(--bg-3)",
          borderRadius: "var(--radius)", border: "1px solid var(--border)",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 6 }}>
            <span style={{ fontSize: "0.75rem" }}>📄</span>
            <span style={{ fontSize: "0.75rem", color: "var(--text-2)", fontWeight: 500 }}>{c.doc}</span>
            <span className="badge badge-process">p.{c.page}</span>
          </div>
          <p style={{ fontSize: "0.78rem", color: "var(--text-3)", lineHeight: 1.55,
            fontStyle: "italic", borderLeft: "2px solid var(--border-2)", paddingLeft: 8 }}>
            "{c.excerpt}"
          </p>
        </div>
      ))}
    </div>
  );
}

function EmptyPanel({ message }: { message: string }) {
  return (
    <div style={{ textAlign: "center", padding: "40px 16px" }}>
      <div style={{ fontSize: "1.8rem", marginBottom: 12, opacity: 0.3 }}>◎</div>
      <p style={{ fontSize: "0.8rem", color: "var(--text-3)", lineHeight: 1.6 }}>{message}</p>
    </div>
  );
}

function ProcessingPanel({ status, progress }: { status: DocStatus; progress: number }) {
  return (
    <div style={{ padding: "24px 0" }}>
      <p style={{ fontSize: "0.8rem", color: "var(--text-2)", marginBottom: 16, textAlign: "center" }}>
        {status === "uploading" ? "Uploading…" : "Extracting content…"}
      </p>
      <div className="progress-track">
        <div className="progress-fill" style={{ width: progress + "%" }} />
      </div>
      <p style={{ textAlign: "right", fontSize: "0.7rem", color: "var(--text-3)", marginTop: 6,
        fontFamily: "var(--font-mono)" }}>
        {progress}%
      </p>
    </div>
  );
}

function UploadPrompt({ onUpload }: { onUpload: () => void }) {
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      background: "var(--bg-3)", border: "1px solid var(--border-2)",
      borderRadius: "var(--radius)", padding: "10px 14px", marginBottom: 10,
    }}>
      <span style={{ fontSize: "1rem" }}>📎</span>
      <p style={{ flex: 1, fontSize: "0.8rem", color: "var(--text-2)" }}>
        No documents uploaded yet.
      </p>
      <button className="btn btn-outline" style={{ fontSize: "0.75rem", padding: "5px 12px" }} onClick={onUpload}>
        Upload
      </button>
    </div>
  );
}
